jQuery(document).ready(function() {	
	(function ($){
		
		var old_href = $('.my_account_link > a').attr('href');

		var new_href = '';

		if(window.location.href.indexOf("referer") >= 0){		
			var res = window.location.href.split("?referer");
			new_href = res[0];
		}else{
			new_href = window.location.href;
		}

		var new_href_final = old_href+'?referer='+new_href;
		$('.my_account_link > a').attr('href', new_href_final);

		$(document.body).on('click','.booking-cancel .cancel',function(e){
			//ovr_cancel_appointment

			appt_id = $(this).attr('data-appt-id');

			$('body').css('cursor','wait');

			//booked_cancel_appt
			$.ajax({
				'url' 		: ajax_object.ajax_url,
				'method' 	: 'post',
				'data'		: {
					'action'     	: 'ovr_cancel_appointment',
					'appt_id'     	: appt_id
				},
				success: function(data) {
					alert('Appointment has been cancelled and funds refunded to your account');
					$('body').css('cursor','default');
					window.location.href = ajax_object.site_url+"/my-account/orders/";
				}
			});

		});

	}(jQuery));
});// - document ready