jQuery(document).ready(function($){
    
	$(document.body).on('click','.action.column-action .cancel',function(e){
        //ovr_cancel_appointment

        appt_id = $(this).attr('data-appt-id');

        $('body').css('cursor','wait');

        //booked_cancel_appt
        $.ajax({
            'url'       : ajax_object.ajax_url,
            'method'    : 'post',
            'data'      : {
                'action'        : 'ovr_cancel_appointment',
                'appt_id'       : appt_id
            },
            success: function(data) {
                //alert(data);
                alert('Appointment has been cancelled and funds refunded to the user');
                $('body').css('cursor','default');
                window.location.href = ajax_object.site_url+'/wp-admin/edit.php?post_type=booked_appointments';
            }
        });

    });

    if( $('body').hasClass('toplevel_page_booked-appointments') ){

        $(document).on('click','a[data-user-id="513"]', function(e){
            alert('abc');
        });

        $(document.body).on('click','.bookedAppointmentTab.active .timeslot .timeslot-count .spots-available', function(e){
            e.preventDefault();
            alert('clicked');
        });        
    }

});